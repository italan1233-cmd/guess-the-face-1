# Guess-the-Face<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Guess the Face</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <!-- Start Button -->
  <div id="start-screen">
    <button id="start-btn">Start</button>
  </div>

  <!-- Game UI -->
  <div id="game-screen" style="display: none;">
    <!-- Symbol Sign -->
    <div id="symbol-sign">
      <span id="symbol-1">😊</span>
      <span id="symbol-2">😐</span>
      <span id="symbol-3">😢</span>
    </div>

    <!-- Doors Container -->
    <div id="doors">
      <div class="door" id="left-door">😊</div>
      <div class="door" id="middle-door">😐</div>
      <div class="door" id="right-door">😢</div>
    </div>

    <!-- Buttons -->
    <div id="controls">
      <button id="left-btn">Left</button>
      <button id="middle-btn">Middle</button>
      <button id="right-btn">Right</button>
    </div>

    <!-- Timer -->
    <div id="timer">Time: 10s</div>
  </div>

  <script src="script.js"></script>
</body>
</html>body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background: #f0f0f0;
}

#start-screen {
  display: flex;
  justify-content: center;
}

#start-btn {
  padding: 20px 40px;
  font-size: 20px;
}

#game-screen {
  text-align: center;
}

#symbol-sign {
  margin-bottom: 20px;
}

.door {
  display: inline-block;
  width: 100px;
  height: 150px;
  margin: 0 10px;
  text-align: center;
  line-height: 150px;
  font-size: 40px;
  background: #ddd;
  border: 2px solid #333;
}

#controls {
  margin-top: 20px;
}

button {
  font-size: 18px;
  margin: 10px;
  padding: 10px;
}

#timer {
  margin-top: 20px;
  font-size: 20px;
  color: #ff0000;
  font-weight: bold;
}// Element selectors
const startScreen = document.getElementById("start-screen");
const startBtn = document.getElementById("start-btn");
const gameScreen = document.getElementById("game-screen");
const symbolSign = document.getElementById("symbol-sign");
const doors = document.querySelectorAll(".door");
const leftBtn = document.getElementById("left-btn");
const middleBtn = document.getElementById("middle-btn");
const rightBtn = document.getElementById("right-btn");
const timerDisplay = document.getElementById("timer");

let round = 1;
let timeLeft = 10; // Start with 10 seconds
let sequence = [];
let playerSequence = [];
let timer;

// Start Button Logic
startBtn.addEventListener("click", startGame);

function startGame() {
  // Hide start screen and show game screen
  startScreen.style.display = "none";
  gameScreen.style.display = "block";
  nextRound();
}

// Start the next round
function nextRound() {
  resetGame();
  generateSequence();
  updateDoors();
  startTimer();
}

// Generate the symbol sequence
function generateSequence() {
  const symbols = ["😊", "😐", "😢"];
  sequence = [];
  for (let i = 0; i < 3; i++) {
    const randomSymbol = symbols[Math.floor(Math.random() * symbols.length)];
    sequence.push(randomSymbol);
    document.getElementById(`symbol-${i + 1}`).textContent = randomSymbol;
  }
}

// Update door symbols
function updateDoors() {
  sequence.forEach((symbol, index) => {
    doors[index].textContent = symbol;
  });
}

// Reset game state for the next round
function resetGame() {
  playerSequence = [];
  timeLeft = 10 - (round - 1) * 2; // Decrease time per round
  if (timeLeft <= 0) {
    endGame(false);
  }
}

// Handle button clicks
leftBtn.addEventListener("click", () => chooseDoor("Left"));
middleBtn.addEventListener("click", () => chooseDoor("Middle"));
rightBtn.addEventListener("click", () => chooseDoor("Right"));

function chooseDoor(direction) {
  const doorSymbols = {
    Left: doors[0].textContent,
    Middle: doors[1].textContent,
    Right: doors[2].textContent,
  };

  playerSequence.push(doorSymbols[direction]);
  if (playerSequence.length === sequence.length) {
    validateSequence();
  }
}

// Validate player input
function validateSequence() {
  if (JSON.stringify(playerSequence) === JSON.stringify(sequence)) {
    // Correct sequence
    round++;
    nextRound();
  } else {
    endGame(false);
  }
}

// Timer functionality
function startTimer() {
  clearInterval(timer);
  timerDisplay.textContent = `Time: ${timeLeft}s`;

  timer = setInterval(() => {
    timeLeft--;
    timerDisplay.textContent = `Time: ${timeLeft}s`;

    if (timeLeft <= 0) {
      clearInterval(timer);
      endGame(false);
    }
  }, 1000);
}

// End game
function endGame(win = true) {
  clearInterval(timer);
  alert(win ? "You Won!" : "Game Over!");
  location.reload(); // Restart game
}// End game
function endGame(win = true) {
  clearInterval(timer);
  if (win) {
    alert("You Win!");
  } else {
    alert("You Lost");
  }
  location.reload(); // Restart game
}